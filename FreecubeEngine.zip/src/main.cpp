\
#include "audio_engine.h"
#include <iostream>

int main() {
    std::cout << "FreecubeEngine - minimal starter\n";
    AudioEngine engine;
    if (!engine.init()) {
        std::cerr << "Failed to initialize audio engine\n";
        return 1;
    }
    std::cout << "Audio engine started. Playing test tone. Press Enter to stop.\n";
    engine.start();
    std::cin.get();
    engine.stop();
    engine.shutdown();
    std::cout << "Stopped.\n";
    return 0;
}
