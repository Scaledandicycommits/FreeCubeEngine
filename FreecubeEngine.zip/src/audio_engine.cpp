\
#include "audio_engine.h"
#include <cmath>
#include <cstring>
#include <iostream>

AudioEngine::AudioEngine() {}
AudioEngine::~AudioEngine() {}

bool AudioEngine::init() {
    PaError err = Pa_Initialize();
    if (err != paNoError) {
        std::cerr << "Pa_Initialize error: " << Pa_GetErrorText(err) << "\n";
        return false;
    }
    return true;
}

void AudioEngine::start() {
    PaError err;
    PaStreamParameters outParams;
    outParams.device = Pa_GetDefaultOutputDevice();
    if (outParams.device == paNoDevice) {
        std::cerr << "No default output device.\n";
        return;
    }
    outParams.channelCount = 2; // stereo output
    outParams.sampleFormat = paFloat32;
    outParams.suggestedLatency = Pa_GetDeviceInfo(outParams.device)->defaultLowOutputLatency;
    outParams.hostApiSpecificStreamInfo = nullptr;

    double sampleRate = 48000.0;
    err = Pa_OpenStream(&stream, nullptr, &outParams, sampleRate,
                        paFramesPerBufferUnspecified, paNoFlag,
                        &AudioEngine::paCallback, this);
    if (err != paNoError) {
        std::cerr << "Pa_OpenStream error: " << Pa_GetErrorText(err) << "\n";
        stream = nullptr;
        return;
    }

    err = Pa_StartStream(stream);
    if (err != paNoError) {
        std::cerr << "Pa_StartStream error: " << Pa_GetErrorText(err) << "\n";
    }
}

void AudioEngine::stop() {
    if (stream) {
        Pa_StopStream(stream);
        Pa_CloseStream(stream);
        stream = nullptr;
    }
}

void AudioEngine::shutdown() {
    Pa_Terminate();
}

// Simple callback generating a sine tone (stereo)
int AudioEngine::paCallback(const void *inputBuffer, void *outputBuffer,
                            unsigned long framesPerBuffer,
                            const PaStreamCallbackTimeInfo* timeInfo,
                            PaStreamCallbackFlags statusFlags,
                            void *userData)
{
    AudioEngine* self = reinterpret_cast<AudioEngine*>(userData);
    float *out = reinterpret_cast<float*>(outputBuffer);
    (void) inputBuffer;
    for (unsigned long i = 0; i < framesPerBuffer; ++i) {
        float sample = static_cast<float>(sin(2.0 * M_PI * self->phase));
        self->phase += self->phaseIncrement;
        if (self->phase >= 1.0) self->phase -= 1.0;
        // stereo interleaved
        out[2*i] = sample * 0.2f;
        out[2*i+1] = sample * 0.2f;
    }
    return paContinue;
}
