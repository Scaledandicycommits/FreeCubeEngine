\
#pragma once
#include <portaudio.h>
#include <vector>

class AudioEngine {
public:
    AudioEngine();
    ~AudioEngine();

    bool init();
    void start();
    void stop();
    void shutdown();

private:
    PaStream *stream = nullptr;
    static int paCallback(const void *inputBuffer, void *outputBuffer,
                          unsigned long framesPerBuffer,
                          const PaStreamCallbackTimeInfo* timeInfo,
                          PaStreamCallbackFlags statusFlags,
                          void *userData);

    // Simple state for generating a test tone
    double phase = 0.0;
    double phaseIncrement = 440.0 / 48000.0; // A4 at 48k sample rate
};
