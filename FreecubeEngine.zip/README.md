\
# FreecubeEngine

FreecubeEngine is an open-source starter audio engine designed for Hi-Res, binaural 3D and real surround audio.  
This package is ready to upload to GitHub as-is.

## What's included
- Minimal C++ audio engine using PortAudio (test tone playback)
- CMake build system
- README and MIT license placeholder

## Build (macOS / Linux)
Install dependencies (example for macOS with Homebrew):
```
brew install portaudio cmake
```

Build steps:
```
mkdir build
cd build
cmake ..
make
./freecube
```

## Next steps
- Replace test tone with input capture (BlackHole) to process Dolphin audio
- Integrate FFT convolution for HRTF binaural rendering
- Add upmix matrix for 2→5.1 and optional multichannel output
- Add resampling pipeline (libsamplerate) for internal Hi-Res processing

## License
MIT — include LICENSE file if you want to customize.
